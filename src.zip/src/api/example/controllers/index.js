import { exampleFindOneController } from '~/src/api/example/controllers/example-find-one.js'
import { exampleFindAllController } from '~/src/api/example/controllers/example-find-all.js'

export { exampleFindOneController, exampleFindAllController }
