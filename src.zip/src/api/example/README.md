# Example API endpoints

This is a bare-bones example of how to create an API controller, with example tests. Modify, remove or updates as
you wish.
