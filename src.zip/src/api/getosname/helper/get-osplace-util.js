import { proxyFetch } from '~/src/api/common/helpers/proxy'
import { fetchData } from '~/src/api/getosname/helper/fetch-data'
import { config } from '~/src/config'
import{processMatches,
    convertStringToHyphenatedLowercaseWords}
    from '~/src/api/getosname/helper/middleware-helpers'


async function fetchOSPlaces(request){
const url = config.get('osNamesApiUrl')
let locationType = 'uk-location';
let locationNameOrPostcode = 'London'
let userLocation = 'LONDON'
const { getOSPlaces } =
await fetchData(locationType, locationNameOrPostcode, request, 'h')
if (locationType === 'uk-location') {
    let { results } = getOSPlaces
  
//const { results } = getOSPlaces
//return {getOSPlaces}

    // Remove duplicates from the results array
    results = Array.from(
        new Set(results.map((item) => JSON.stringify(item)))
      ).map((item) => JSON.parse(item))
      const selectedMatches = processMatches(
        results,
        locationNameOrPostcode,
        userLocation
      )
      return selectedMatches
    }

//return {getOSPlaces}
}
export { fetchOSPlaces }