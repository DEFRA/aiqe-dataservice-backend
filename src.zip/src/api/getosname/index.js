import {
  osplaceController
} from '~/src/api/getosname/controller/osplace.js'

/**
 * @satisfies {ServerRegisterPluginObject<void>}
 */
const osnameplaces = {
  plugin: {
    name: 'osnameplaces',
    register: async (server) => {
      server.route([
        {
          method: 'GET',
          path: '/osnameplaces',
          ...osplaceController
        }
      ])
    }
  }
}
export { osnameplaces }

/**
 * @import { ServerRegisterPluginObject } from '@hapi/hapi'
 */
